#!/bin/bash
#num=$[ RANDOM%10+1 ]
#read -p "随机数，你猜：" cai
while :
do
num=$[ RANDOM%10+1 ]
	read -p "随机数，你猜：" cai
	[ $cai = $num ] && echo "猜对了" || echo "猜错了"
done
