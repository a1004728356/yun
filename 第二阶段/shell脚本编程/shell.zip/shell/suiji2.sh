#!/bin/bash
num=$[ RANDOM%10+1 ]
i=0
#read -p "随机数，你猜：" cai
#if [ $cai -eq $num ];then
#	echo "猜对了"
#elif [ $cai -gt $num ];then
#	echo "猜大了"
#else
#	echo "猜小了"
#fi
while :
do
	read -p "请输入：" cai
	let i++
	if [ $cai -eq $num ];then
		echo "恭喜，你猜了$i次"
		exit
	elif [ $cai -gt $num ];then
		echo "猜大了"
	else 
		echo "猜小了"
	fi
done
