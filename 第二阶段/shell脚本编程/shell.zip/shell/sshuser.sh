#!/bin/bash
#过滤账户名失败的命令（登录日志为/var/log/secure）
#awk '/Invalid user/{print $10}' /var/log/secure
#过滤密码失败的命令
#awk '/Failed password/{print $11}' /var/log/secure
awk '/Failed password/{print $11}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print "密码失败:",ip[i],i}}' |awk '$1>3{print $2}'
awk '/Invalid user/{print $10}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print ip[i],i}}' |awk '$1>3{print $2}'

