#!/bin/bash
#书写一个成绩判断的脚本
#用户输入成绩，0到100之间
#如果成绩大于等于90分以上，则输出优秀
#如果成绩大于等于80分以上，则输出良好
#如果成绩大于等于60分以上，则输出及格
#如果成绩小于60分，则输出不及格
read -p '请输入成绩' nsd
if [ $nsd -ge 90 ];then
	echo 优秀
elif [ $nsd -ge 80  ];then
	echo 良好
elif [ $nsd -ge 60  ];then
	echo 及格
else
	echo 不及格
fi
