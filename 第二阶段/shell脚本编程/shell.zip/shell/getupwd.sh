#!/bin/bash
user=`sed -n '/bash$/s/:.*//p' /etc/passwd`

for i in $user
do
	pass=`grep -r "$i" /etc/shadow`
	pass1=${pass#*:}
	pass2=${pass1%%:*}
	echo "$i --->$pass2"	
done
