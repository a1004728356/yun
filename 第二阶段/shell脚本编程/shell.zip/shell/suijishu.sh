#!/bin/bash
#计算机随机产生一个0到9之间的数字
#用户输入一个0到9之间的数字
#如果用户输入的数字与计算机随机产生相等，则输出您猜对了
#如果用户输入的数字与计算机随机产生不相等，则输出猜错了
#RANDOM：系统存储随机产生数字
for i in {1..6}
do
read -p '请输入0-9之间的数字：' num1
num2=$[ $RANDOM%10 ]
if [ $num1 -eq $num2 ];then
	echo 您猜对了
	exit
else
	echo 您猜错了
	echo 正确的数字是$num2
fi
done
