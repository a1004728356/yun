#!/bin/bash
if [ -e "/media/iso" ]
	then echo ok
	else
		mkdir /media/iso && echo OK
fi
