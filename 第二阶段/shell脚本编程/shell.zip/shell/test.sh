#!/bin/bash
echo $0   #脚本的名称
echo $1   #第一个参数
echo $2   #第二个参数
echo $3   #第三个参数
echo $*   #所有位置变量的值
echo $#   #已加载位置变量的个数
echo $$   #当前运行进程的PID号
echo $?   #上一个程序的返回状态码

