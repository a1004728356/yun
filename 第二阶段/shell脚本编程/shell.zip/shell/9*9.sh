#!/bin/bash
for ((i=1;i<=9;i++))
do
	for ((j=1;j<=i;j++))
do
	echo -n "$i*$j=$[i*j] "
done
	echo
done
#
for i in `seq 9`
do
	for j in `seq $i`
	do
		echo -n "$i*$j=$[i*j] "
	done
	echo
done
#
for i in `seq 9`
do
	for j in `seq 9`
	do
		if [ $j -le $i ];then
		echo -n "$i*$j=$[i*j] "
		fi
	done
	echo
done
#
for i in `seq 9`
do
	j=0
	while [ $j -lt $i ]
	do
		((j=j+1))
		echo -n "$i*$j=$[i*j] "
	done
	echo
done
