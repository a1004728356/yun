#!/bin/bash
#利用read读入用户输入的用户名，脚本判断本机能否有该用户
#如果有，输出用户已存在
#如果没有，输出用户不存在
read -p '请输入用户名' sss
id $sss &> /dev/null
if [ $? -eq 0 ];then
	echo 用户已存在
else
	echo 用户不存在
fi
