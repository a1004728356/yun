#!/bin/bash
yum -y install vsftpd &> /dev/null
sed -i '/^#anon/s/^#//' /etc/vsftpd/vsftpd.conf
#sed -i 's/^#anon_upload.*/anon_upload_enabled=YES/g' /etc/vsftpd/vsftpd.conf
chown -R ftp /var/ftp/pub
systemctl start vsftpd

