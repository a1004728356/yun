#!/bin/bash
for i in `seq 1 2 10`
do
	echo $i
done
for ((i=1;i<=5;i++))
do
	echo $i
done
