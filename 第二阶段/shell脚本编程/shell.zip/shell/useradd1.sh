#!/bin/bash
read -p "请输入用户名：" user
[ -z "$user" ] && exit
stty -echo 
read -p "请输入密码：" pass
stty echo
[ -z "$pass" ] && echo '输入错误' && exit
echo ""
useradd $user
echo "$pass" | passwd --stdin $user
#stty设置隐藏密码
