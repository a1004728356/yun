#!/bin/sh
x=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789
#1.随机生成一个密码
#n=$[RANDOM%62]
#echo ${x:n:1}
n=$[RANDOM%62+1]
echo $x | cut -b $n
#2.随机生成一个8位密码
pass=''
for i in {1..8}
do
n=$[RANDOM%62]
tmp=${x:n:1}
pass=$pass$tmp
done
echo $pass
