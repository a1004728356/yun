#!/bin/bash
read -p "请输入IP地址:" a
ping -c 3 -i 0.1 $a &> /dev/null
if [ $? -eq 0 ]
	then
		echo "能Ping通"
	else
		echo "Ping不同"
fi
