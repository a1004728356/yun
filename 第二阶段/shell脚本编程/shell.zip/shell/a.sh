#!/bin/bash
#> a.log
date >> a.log
for i in {1..10}
do 
	useradd user$i 2>>a.log
	echo "123" | passwd --stdin user$i > /dev/null
done
