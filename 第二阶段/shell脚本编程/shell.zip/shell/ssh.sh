#!/bin/bash
#ssh -o StrictHostkeyChecking=no 表示默认接受密钥
expect << EOF
set timeout 60
spawn ssh  -o StrictHostkeyChecking=no 132.232.56.166 
expect "password" {send "ljh13835188586?\n"}
expect "#" {send "touch /nb.txt\n"}
expect "#" {send "exit\n"}
EOF
