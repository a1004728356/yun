#!/bin/bash
num=`who | wc -l`
[ $num -ge 3 ] && mail -s error root < /root/shell/mail
