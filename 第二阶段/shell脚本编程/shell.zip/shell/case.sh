#!/bin/bash
case $1 in
redhat)
	echo "fedora";;
fedora)
	echo 1
	echo redhat;;
*)
	echo "usage";;
esac
