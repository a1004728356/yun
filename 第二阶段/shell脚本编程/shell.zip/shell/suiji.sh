#!/bin/bash
num=$[ RANDOM%10+1 ]
read -p "随机数，你猜：" cai
if [ $cai -eq $num ];then
	echo "猜对了"
elif [ $cai -gt $num ];then
	echo "猜大了"
else
	echo "猜小了"
fi
