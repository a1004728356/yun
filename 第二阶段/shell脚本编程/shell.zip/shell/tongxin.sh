#!/bin/bash
#用户输入一个ip地址，脚本判断本机能否与该IP地址通信
#如果能 则输出 可以通信
#如果不能 则输出 不可以通信
ping  -c 2 $1 &> /dev/null
if [ $? -eq 0 ];then
	echo 可以通信
else
	echo 不可以
fi
