#!/bin/bash
#此脚本要求提供用户名列表文件作为参数
#如果没有提供参数，此脚本应该给出提示usage:/root/batrchusers.sh，并退出返回相应的值
#如果提供一个不存在的文件，此脚本应该给出提示input file no found，退出并返回相应的值
#新用户的登录shell为/bin/false,无需设置密码
#自己编写测试文件userlist
if [ $# -eq 0 ];then
	echo 'usage:/root/batrchusers.sh' >&2
	exit 2
elif [ -f $1 ];then
	for i in `cat $1`
	do 
		useradd -s /bin/false $i
		echo $i创建成功
	done
else
 	echo 'input file no found' >&2
 	exit 3
fi
