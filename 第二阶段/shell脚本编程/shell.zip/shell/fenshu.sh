#!/bin/bash
read -p "请输入成绩：" num
if [ $num -ge 90 ];then
	echo "神功盖世"
elif [ $num -ge 80 ];then
	echo "登峰造极"
elif [ $num -ge 70 ];then
	echo "炉火纯青"
elif [ $num -ge 60 ];then
	echo "略有小成"
else
	echo "初学乍练"
fi
