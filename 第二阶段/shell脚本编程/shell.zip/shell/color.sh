#!/bin/bash
cecho(){
	echo -e "\033[$1m$2\033[0m"
}
cecho 31 王博
cecho 32 张
cecho 41 解放
