#!/bin/bash
#用来从键盘读入一个正整数x，求从1到x的和；当用户未设置值时，为了避免执行出错，应为x赋值为100
read -p "请输入数字：" x 
x=${x:-100}
i=1
sum=0
#for i in `seq $x`
#do
#	sum=$[sum+i]
#done
#echo "从1到$x的总和是：$sum"
while [ $i -le $x ]
do
	sum=$[sum+i]
	i=$[i+1]
done
echo "从1到$x的总和是：$sum"
