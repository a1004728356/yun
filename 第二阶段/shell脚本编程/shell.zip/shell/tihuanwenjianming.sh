#!/bin/bash
for i in `ls /root/*.doc`
do
	mv $i ${i%.}.txt
done
