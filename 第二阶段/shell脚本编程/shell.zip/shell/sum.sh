#!/bin/bash
#sum=0
#while :
#do
#	read -p "请输入数字" num
#	[ $num -eq 0  ] && break
#	sum=$[sum+num]
#done
#echo $sum
for i in {1..20}
do
	num=$[ i%6 ]
		[ $num -ne 0 ] && continue
		echo $[i*i]
done

