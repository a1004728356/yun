#!/bin/bash
#for i in `seq 254`
#do 
#	ping -c 2 -i 0.1 -W 1 116.196.101.$i &> /dev/null
#	if [ $? -eq 0 ];then
#		echo "116.196.101.$i is up"
#	else
#		echo "116.196.101.$i is down"
#	fi
#done
i=1
while [ $i -le 254 ]
do
	ping -c 2 -i 0.1 -W 1 116.196.101.$i &> /dev/null
	#ping -c 2 -i 0.1 -W 1 192.168.4.1 &> /dev/null
	if [ $? -eq 0 ];then
		echo "116.196.101.$i is up"
	else
		echo "116.196.101.$i is down"
	fi
	let i++
done
